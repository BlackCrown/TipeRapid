This project uses AGENTS.md as the source of truth for AI assistant behavior.

See ./AGENTS.md for full instructions on how to assist with this challenge.
